﻿// See https://aka.ms/new-console-template for more information
using System.IO;
namespace Avaliacao
{
    internal class Program
    {
        static void Main(string[] args)
        {
            UserRepository _user = new();
            Console.WriteLine("SEJA BEM-VINDO AO AMBIENTE DE USUÁRIOS CTEDS!!!");
            string option = "2";
            string email;
            string senha;          



            while (option != "0") 
            {
                if (option == "2")
                {
                    Console.WriteLine("\nEscolha uma das opções abaixo:\n");
                    Console.WriteLine("1 - Acessar");
                    Console.WriteLine("0 - Cancelar\n");
                    option = Console.ReadLine();
                }
                

                if (option == "1")
                {
                    Console.WriteLine("Digite seu e-mail:\n");
                    email = Console.ReadLine();
                    Console.WriteLine("Digite a sua senha:\n");
                    senha = Console.ReadLine();
                    var usertList = _user.ReadAll();
                 
                    if (email == usertList[0].Email && senha == usertList[0].Senha)
                    {
                        Console.WriteLine("Login efetuado com sucesso!");
                        
                        string registro = "O usuário " + usertList[0].Name + " acessou o sistema às " + DateTime.Now.ToString("hh:mm:ss tt")+ "do dia " + DateTime.Now.ToString("dd/MM/yyyy") +"\n";

                        System.IO.File.WriteAllText("Registro.txt", registro);
                        string readText = File.ReadAllText("Registro.txt");
                        Console.WriteLine(readText);
                        Console.WriteLine("\nEscolha uma das opções abaixo:\n");
                        Console.WriteLine("2 - deslogar");
                        Console.WriteLine("0 - encerrar o sistema\n");

                       

                        option = Console.ReadLine();
                    }

                    else
                    {
                        Console.WriteLine("Login com erro! ");
                        option = "1";
                    }
                }



            }
        }
    }
}