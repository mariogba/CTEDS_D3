

-- Define qual banco de dados ser� utilizado
USE [db_18];
GO

-- Cria a tabela Products
CREATE TABLE Usuario(
	Id		    INT NOT NULL UNIQUE,
	[Name]			    VARCHAR(255) NOT NULL,
	[Email]		TEXT NOT NULL,
	Senha			    varchar(255) NOT NULL
);
GO


-- Insere um registro na tabela
INSERT INTO Usuario (Id, [Name], [Email], Senha)
VALUES				 ('0', 'admin', 'admin@email.com','admin123');
GO


SELECT * FROM Usuario;
GO
